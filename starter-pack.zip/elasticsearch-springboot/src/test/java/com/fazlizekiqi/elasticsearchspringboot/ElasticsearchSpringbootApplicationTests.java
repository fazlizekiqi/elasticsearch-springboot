package com.fazlizekiqi.elasticsearchspringboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ElasticsearchSpringbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
